
#TUM eAccess Add-on for FireFox and Microsoft Edge

[FireFox Add-on](https://www.google.de/) and [Microsoft Edge Add-on](https://www.google.de/), helping to access scientific papers more easily 

